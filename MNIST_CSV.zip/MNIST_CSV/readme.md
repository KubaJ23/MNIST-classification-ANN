The format is
    label, pix-11, pix-12, pix-13, ...

Refer to [MNIST in CSV](https://pjreddie.com/projects/mnist-in-csv/)

